Information about Oracle:-
------------------------
==> "a.out" is a executable file, which acts like Oracle Here.
==> Oracle takes 11 input (i1,i2,i3,i4,i6,G1,G2,G3,G4,GG1,GG2).
==> Oracle Gives us 4 Output (o1,o2,o3,o4).

To run the oracle you have to execute [./a.out 1 2 3 4 5 6 7 8 9 10 11] where value of i1=1,i2=2,i3=3,i4=4,i6=5,G1=6,G2=7,G3=8,G4=9,GG1=10,GG2=11

Information about Obfuscated File:-
---------------------------------
==> Obfuscated file is the locked C-Code.
==> This code is locked with value Key1 to Key7.
==> You have to find the Correct value of Keys.


