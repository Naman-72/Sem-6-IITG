Information about Oracle:-
------------------------
==> "a.out" is a executable file, which acts like Oracle Here.
==> Oracle takes 11 input (i1,i2,i3,i4,i6,G1,G2,G3,G4,GG1,GG2).
==> Oracle Gives us 4 Output (o1,o2,o3,o4).

Information about Obfuscated File:-
---------------------------------
==> Obfuscated file is the locked C-Code.
==> This code is locked with value Key1 to Key7.
==> You have to find the Correct value of Keys.


