Assumption:
	Since both -45 and +45 are both integer-constant. If you want to do addition/substraction you have to put a space between '-' and '45'.
