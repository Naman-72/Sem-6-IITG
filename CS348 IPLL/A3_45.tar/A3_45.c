#include <stdio.h>
#include "lex.yy.c"
extern char* yytext;
extern char* string;
extern int yylineno;

int main()
{
    int token;
    int keywords_count = 0;
    int identifier_count = 0;
    int constant_count = 0;
    int str_literal_count = 0;
    int punc_count = 0;
    int comment_count = 0;

    // taking input 
    while(token = yylex())
    {
        if(token==comment)
        {
            printf("<Comment , %s>\n", yytext);
            comment_count++;
        }
        else if(token == keywords)
        {
            printf("<Keyword , %s>\n", yytext);
            keywords_count++;
        }
        else if(token == identifier)
        {
            printf("<Identifier , %s>\n", yytext);
            identifier_count++;
        }
        else if(token == constant)
        {
            printf("<Constant , %s>\n", yytext);
            constant_count++;
        }
        else if(token == str_literal)
        {
            printf("<String Literal , %s>\n", yytext);
            str_literal_count++;
        }
        else if(token == punctuators)
        {
            printf("<Punctuator , %s>\n", yytext);
            punc_count++;
        }
        else if(token==whitespace)
        {
        	
        }
        else
        {
            printf("Error on line no : %d, %d\n",yylineno, yytext[0]);
        }
    }
    return 0;
}
