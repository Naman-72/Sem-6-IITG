/* Vedic Partap */
Test File

/*#include<stdio.h>
#include "dummy.h"
struct Node{
	int val=0;
	struct Node*[100];
}
/*main functionm*/
int main()
{
	auto x=9/2;
	enum week{Mon, tue, Wed};
	restrict s;
	register unsigned int x=100;
	extern extern_var=100;
	(void*) vptr;
	float pos = 3.4;
	pos = pos>>2;
	pos= pos<<2;
	short short_int = 23;
	char char_var = 'a';
	for(int static unsigned int i=0;i<=100;i+=1)
	{
		if(pos==3.4)
		{
			break;
		}
		else
		{
			double ret = pos*5.6;
			continue;
		}
	}
	//Construct the node 
	struct Node *test;
	test->val=16;
	test->val++;
	__Bool bool_var = TRUE;

	return 0;
} 