{ 
	int x;
	int y;
	x = 2;
	y = 3;
	x = 5 + y * 4;
}
