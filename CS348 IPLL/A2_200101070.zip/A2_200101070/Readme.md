************************************************************

Assignment 2
Naman Anand
200101070

Assumptions :
1> THE INPUT FILE SHOULD HAVE THE FOLLOWING TYPE OF INSTRUCTIONS

    =>1 word :
    opcode

    =>2 word :
    opcode operand
        or
    label opcode

    =>3 word
    label opcode operand

2> ON ERROR in input file like duplicate entry in symbol table etc I AM JUST PRINTING THE ERROR
   AND NOT BREAKING THE RUNTIME IN BETWEEN
 
3> NOTE THE INPUT ASSEMBLY CODE SHOULD BE IN FILE sample_input.txt in the SAME Directory

4> THERE IS NO SPACE BEFORE AND AFTER ',' WHILE USING INDIRECT ADDRESSING

5> PROGRAM NAME IS ATMOST 6 CHAR LONG

************************************************************
