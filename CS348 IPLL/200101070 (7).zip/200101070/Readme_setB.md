Commands to run :
1)	nasm -f elf64 -g setb.asm
2)	gcc -m64 -no-pie setb.o -o setb
3)	./setb

Assumptions :
1)	Value of n should be between 1 to 4.
2)	User Enter a integer value while taking input from user in matrix.

