Commands to run :
1)	nasm -f elf64 -g seta.asm
2)	gcc -m64 -no-pie seta.o -o seta
3)	./seta

Assumptions :
1)	The filename is hardcoded as textfile.txt (line 219).So for count first create a file and then it will give you char and count.
2)	I am printing all the elements from ascii value 32 to 127 and the count it occured per character.
