#include <bits/stdc++.h>
using namespace std;
#define unicode_count 26
#define FILE_SIZE 14511

// 

unordered_map<string,int> stringIntMap;
unordered_map<int,string> Map;
set<string> S;


/* 

Define a TrieNode struct to represent a node of the Trie, which should include the 
following members:(10 marks)
    ○ children: a structure to store the child nodes of the current node
    ○ isEndOfWord: a boolean flag to indicate if the current node represents the end of a word
*/
// struct

typedef struct TrieNode
{
    string data;
    bool isEndOfWord;
    TrieNode* children[unicode_count];
    TrieNode()
    {
        isEndOfWord = false;
        for (int i = 0; i < unicode_count; i++)
        {
            children[i] = nullptr;
        }
    }
} Node;

/*
Define a Trie class to represent the Trie, which should include the following 
members:(20 marks)
    ○ root: a pointer to the root node of the Trie
*/

class Trie
{
    private:

    public:
        Node* root;
        Trie()
        {
            root = new Node();
            root->data = "";
            root->isEndOfWord = false;
            for (int i = 0; i < unicode_count; i++)
            {
                root->children[i] = nullptr;
            }
            // cout<<"Trie Created";
        }
    // ○ insert(): a function to insert a Hindi word into the Trie, which should take the 
    // following parameter:
    //             ■ word: a string representing the Hindi word to insert
        void insert(string s)
        {
            Node* curr = root;
            for (int i = 0; i < s.size(); i++)
            {
                if(curr->children[s[i]-'a']==nullptr)
                {
                    // cout<<s[i]<<" ";
                    curr->children[s[i]-'a'] = new Node();
                }
                curr = curr->children[s[i]-'a'];
            }
            curr->isEndOfWord = true;
            return;
        }
    // ○ search(): a function to search for a Hindi word in the Trie, which should take the 
    // following parameter:
    //             ■ word: a string representing the Hindi word to search for
    //             ■ Returns true if the word is found in the Trie, false otherwise
        bool search(string s)
        {
            Node* curr = root;
            for (int i = 0; i < s.size(); i++)
            {
                if(curr->children[s[i]-'a']==nullptr)
                {
                    return false;
                }
                curr = curr->children[s[i]-'a'];
            }
            return curr->isEndOfWord;
        }
    // ○ printAllWords(): a function to print all the Hindi words in the Trie
        void Print(string prev,Node* lastnode)
        {
            for (int i = 0; i < unicode_count; i++)
            {
                if(lastnode->children[i]==nullptr)
                {
                    continue;
                }
                else
                {
                    if(lastnode->children[i]->isEndOfWord==true)
                    {
                        S.insert(prev+char('a'+i));
                    }
                    Print(prev+char('a'+i),lastnode->children[i]);
                }
            }
            return;
        }
        void printAllWords()
        {
            Node* curr = root;
            string prev = "";
            Print(prev,root);
            for (auto i : S)
            {
                cout<<i<<endl;
            }
            return;
        }

};



int main()
{
    FILE* fptr;
    fptr = fopen("hindi_text.txt","r");
    wchar_t a;
    // __cpp_unicode_characters; 
    // fscanf(fptr,"%c",&a);
    // cout<<a<<endl;
    // string s = "";
    // s+=a;
    // stack<string> words;
    for (int i = 0; i < FILE_SIZE; i++)
    {
        fscanf(fptr,"%c",&a);
        // cout<<a<<endl;
    }
    
    Trie* Z = new Trie();
    // 900-9ff

    /*
        Testing 
        To test your implementation, you can: 
            ● Insert Hindi words into the Trie and check that they are inserted correctly
            ● Search for Hindi words in the Trie and check that the search returns true for words that 
            are in the Trie, and false for words that are not in the Trie
            ● Print all the Hindi words in the Trie and check that all the words are printed correctly
    */
   

   // I HAVE MADE FOR SMALL CHAR ALPHABET 
   // IT IS WORKING CORRECTLY FOR THAT
   // DON'T KNOW UNICODE CHARACTERS VALUE SO 
    // Now i am trying to change to unicode char
    Z->insert("naman");
    Z->insert("anand");
    Z->insert("a");
    cout<<Z->search("naman")<<endl;
    cout<<Z->search("nama")<<endl;
    Z->printAllWords();
    return 0;
}


//  checking for english dict first
    // Z->insert("apple");
    // Z->insert("app");
    // Z->insert("acot");
    // if(Z->search("acotfaa"))
    // {
    //     cout<<"FOUND";
    // }
    // else
    // {
    //     cout<<"NOT FOUND";
    // }
    // cout<<endl;
    // if(Z->search("appsle"))
    // {
    //     cout<<"FOUND";
    // }
    // else
    // {
    //     cout<<"NOT FOUND";
    // }
    // // Z->insert("mango");
    // // fclose(fptr);
