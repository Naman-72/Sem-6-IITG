# GROUP NO : 11
# ASSIGNMENT 4 

# COMMANDS TO RUN :
## kmeans file :
    
    1> gcc kmeans.c -o kmeans
    2> kmeans.exe

## lbg file :
    
    1> gcc lbg.c -o lbg
    2> lbg.exe

### ASSUMPTIONS :
1> MAXITER FOR LBG AND KMEANS I HAVE DEFINED 200
2> VALUE OF alpha is 1e-3 , VALUE of epsilon : 0.01
    (IT IS CHANGEBLE IN CODE)